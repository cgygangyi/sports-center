<template>
    <a-layout-footer>
        <p class="copyright">
            Copyright © 2023
            by <a href="https://github.com/cgygangyi/XJCO2913">https://github.com/cgygangyi/XJCO2913</a>.
        </p>
    </a-layout-footer>

</template>

<script>

export default ({
    data() {
        return {
        }
    }
})

</script>
