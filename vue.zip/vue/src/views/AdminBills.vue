<template>

</template>

<script>
export default {
    name: "AdminBills"
}
</script>

<style scoped>

</style>
